import Administrator
import Lecturer
import Student
import Registrar
import Accountant


def get_valid_input(prompt, required=True):
    while True:
        value = input(prompt).strip()
        if value or not required:
            return value
        else:
            print("This field cannot be empty. Please try again.")


def login():
    print('Please enter Login credentials')
    print('UserName: "UMSLOGIN", Password: "12589" ')
    username = get_valid_input("Enter Username: ")
    password = get_valid_input("Enter password: ")

    # Assuming you have a file 'security.txt' with username,password pairs
    try:
        with open('security.txt', "r") as file:
            users = file.readlines()
            for user in users:
                stored_name, stored_password = user.strip().split(",")
                if username == stored_name and password == stored_password:
                    print("Login successful!")
                    return True
            print("Invalid username or password. Try again.")
            return False
    except FileNotFoundError:
        print("Security file not found.")
        return False


def main_menu():  # This function is created to prompt user to select a role
    while True:
        print("-------Welcome to University Management System-----------")
        if not login():
            print("Access Denied! Please try logging in again.")
            continue  # Go back to the main menu if login fails
        print("\n---------- Main Menu ----------")
        print("1. Administrator")
        print("2. Lecturer")
        print("3. Student")
        print("4. Registrar")
        print("5. Accountant")
        print("6. Exit")
        choice = input("Enter your choice: ")

        if choice == "1":
            Administrator.admin_menu()
        elif choice == "2":
            Lecturer.lecturer_menu()
        elif choice == "3":
            Student.student_menu()
        elif choice == "4":
            Registrar.registrar_menu()
        elif choice == "5":
            Accountant.accountant_menu()
        elif choice == "6":
            print("Exiting now...")
            break
        else:
            print("Invalid choice, please try again.")


if __name__ == "__main__":
    main_menu()