from datetime import datetime


def admin_menu():
    """
    Display the administrator menu and route user actions to respective management functions.
    Includes input validation, file error handling, and modular tasks for university administration.
    """

    def validate_numeric_input(prompt):
        """Prompt user for numeric input and validate it."""
        while True:
            value = input(prompt).strip()
            if value.isnumeric():
                return value
            print("Invalid input. Please enter a numeric value.")

    def validate_date_input(prompt):
        """Prompt user for a date and validate its format (YYYY-MM-DD)."""
        while True:
            date_str = input(prompt).strip()
            try:
                datetime.strptime(date_str, "%Y-%m-%d")
                return date_str
            except ValueError:
                print("Invalid date format. Please use YYYY-MM-DD.")

    def manage_module():
        """Add, update, or remove module records in the system."""
        print("\nModule Management")
        option = input("Choose an option (Add, Update, Remove): ").strip().lower()

        try:
            if option == "add":
                module_code = input("Enter module code: ").strip()
                module_name = input("Enter module name: ").strip()
                credits = validate_numeric_input("Enter module credits: ")

                with open("modules.txt", "a") as file:
                    file.write(f"{module_code},{module_name},{credits}\n")
                print("Module added successfully.")

            elif option == "update":
                module_code = input("Enter module code to update: ").strip()
                found = False

                with open("modules.txt", "r") as file:
                    lines = file.readlines()

                with open("modules.txt", "w") as file:
                    for line in lines:
                        if line.startswith(module_code + ","):
                            module_name = input("Enter new module name: ").strip()
                            credits = validate_numeric_input("Enter new course credits: ")
                            file.write(f"{module_code},{module_name},{credits}\n")
                            found = True
                        else:
                            file.write(line)

                if found:
                    print("Module updated successfully.")
                else:
                    print("Module not found.")

            elif option == "remove":
                module_code = input("Enter a module code to remove: ").strip()
                found = False

                with open("modules.txt", "r") as file:
                    lines = file.readlines()

                with open("modules.txt", "w") as file:
                    for line in lines:
                        if not line.startswith(module_code + ","):
                            file.write(line)
                        else:
                            found = True

                if found:
                    print("Module removed successfully.")
                else:
                    print("Module not found.")
            else:
                print("Invalid option. Please try again.")
        except FileNotFoundError:
            print("Error: File not found. Ensure 'modules.txt' exists.")

    def manage_student():
        """Add, update, or remove student records in the system."""
        print("\nStudent Management")
        option = input("Choose an option (Add, Update, Remove): ").strip().lower()

        try:
            if option == "add":
                student_id = validate_numeric_input("Enter student ID: ")
                student_name = input("Enter student name: ").strip()
                department = input("Enter department: ").strip()
                AdmissionDate = validate_date_input("Enter Date of Admission [YYYY-MM-DD]:")

                with open("students.txt", "a") as file:
                    file.write(f"{student_id},{student_name},{department},{AdmissionDate}\n")
                print("Student added successfully.")

            elif option == "update":
                student_id = validate_numeric_input("Enter student ID to update: ")
                found = False

                with open("students.txt", "r") as file:
                    lines = file.readlines()

                with open("students.txt", "w") as file:
                    for line in lines:
                        if line.startswith(student_id + ","):
                            student_name = input("Enter new student name: ").strip()
                            department = input("Enter new department: ").strip()
                            file.write(f"{student_id},{student_name},{department}\n")
                            found = True
                        else:
                            file.write(line)

                if found:
                    print("Student updated successfully.")
                else:
                    print("Student not found.")

            elif option == "remove":
                student_id = validate_numeric_input("Enter student ID to remove: ")
                found = False

                with open("students.txt", "r") as file:
                    lines = file.readlines()

                with open("students.txt", "w") as file:
                    for line in lines:
                        if not line.startswith(student_id + ","):
                            file.write(line)
                        else:
                            found = True

                if found:
                    print("Student removed successfully.")
                else:
                    print("Student not found.")
            else:
                print("Invalid option. Please try again.")
        except FileNotFoundError:
            print("Error: File not found. Ensure 'students.txt' exists.")

    def manage_lecturer():
        """Add, update, or remove lecturer records in the system."""
        print("\nLecturer Management")
        option = input("Choose an option (Add, Update, Remove): ").strip().lower()

        try:
            if option == "add":
                lecturer_id = validate_numeric_input("Enter lecturer ID: ")
                lecturer_name = input("Enter lecturer name: ").strip()
                department = input("Enter department: ").strip()
                HiringDate = validate_date_input("Enter Date of Registration [YYYY-MM-DD]:")

                with open("lecturers.txt", "a") as file:
                    file.write(f"{lecturer_id},{lecturer_name},{department},{HiringDate}\n")
                print("Lecturer added successfully.")

            elif option == "update":
                lecturer_id = validate_numeric_input("Enter lecturer ID to update: ")
                found = False

                with open("lecturers.txt", "r") as file:
                    lines = file.readlines()

                with open("lecturers.txt", "w") as file:
                    for line in lines:
                        if line.startswith(lecturer_id + ","):
                            lecturer_name = input("Enter new lecturer name: ").strip()
                            department = input("Enter new department: ").strip()
                            file.write(f"{lecturer_id},{lecturer_name},{department}\n")
                            found = True
                        else:
                            file.write(line)

                if found:
                    print("Lecturer updated successfully.")
                else:
                    print("Lecturer not found.")

            elif option == "remove":
                lecturer_id = validate_numeric_input("Enter lecturer ID to remove: ")
                found = False

                with open("lecturers.txt", "r") as file:
                    lines = file.readlines()

                with open("lecturers.txt", "w") as file:
                    for line in lines:
                        if not line.startswith(lecturer_id + ","):
                            file.write(line)
                        else:
                            found = True

                if found:
                    print("Lecturer removed successfully.")
                else:
                    print("Lecturer not found.")
            else:
                print("Invalid option. Please try again.")
        except FileNotFoundError:
            print("Error: File not found. Ensure 'lecturers.txt' exists.")

    def view_all_data():
        """Display all data from students, modules, and lecturers with timestamps."""
        try:
            print("\nViewing All Data:")
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            print(f"Data viewed on: {timestamp}")

            print("\nAll Students Data:")
            with open("students.txt", "r") as file:
                print(file.read())

            print("\nAll Modules Data:")
            with open("modules.txt", "r") as file:
                print(file.read())

            print("\nAll Lecturers Data:")
            with open("lecturers.txt", "r") as file:
                print(file.read())
        except FileNotFoundError:
            print("Error: One or more files are missing. Ensure all required files exist.")

    def generate_reports():
        """Generate reports for the system with a timestamp."""
        print("\nGenerating Reports")
        try:
            student_count = sum(1 for _ in open("students.txt", "r"))
            module_count = sum(1 for _ in open("modules.txt", "r"))
            lecturer_count = sum(1 for _ in open("lecturers.txt", "r"))
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

            print(f"Reports generated on: {timestamp}")
            print(f"Total Students: {student_count}")
            print(f"Active Modules: {module_count}")
            print(f"Total Lecturers: {lecturer_count}")
        except FileNotFoundError:
            print("Error: One or more files are missing. Ensure all required files exist.")

    while True:
        print("\n---------- University Administrator ------------")
        print("1. Manage Modules")
        print("2. Manage Students")
        print("3. Manage Lecturers")
        print("4. View All Data")
        print("5. Generate Reports")
        print("6. Exit")
        choice = input("Enter your choice: ").strip()

        if choice == "1":
            manage_module()
        elif choice == "2":
            manage_student()
        elif choice == "3":
            manage_lecturer()
        elif choice == "4":
            view_all_data()
        elif choice == "5":
            generate_reports()
        elif choice == "6":
            print("Exiting Administrator menu.")
            break
        else:
            print("Invalid choice. Please try again.")