from datetime import datetime


def get_valid_input(prompt, required=True):
    while True:
        value = input(prompt).strip()
        if value or not required:
            return value
        else:
            print("This field cannot be empty. Please try again.")


def validate_numeric_input(prompt):
    while True:
        value = input(prompt).strip()
        if value.isnumeric():
            return value
        print("Invalid input. Please enter a numeric value.")


def validate_date_input(prompt):
    while True:
        date_str = input(prompt).strip()
        try:
            datetime.strptime(date_str, "%Y-%m-%d")
            return date_str
        except ValueError:
            print("Invalid date format. Please use YYYY-MM-DD.")


def registrar_menu():
    def register_new_student():
        print("Register New Student")
        student_id = validate_numeric_input("Enter Student ID: ")

        if check_student_id_exists(student_id):
            print(f"Student ID {student_id} has already been registered.")
            return

        student_name = get_valid_input("Enter Student Name: ")
        program = get_valid_input("Enter Program Name: ")

        try:
            with open("students.txt", "a") as file:
                file.write(f"{student_id},{student_name},{program}\n")
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            print("Student registered on:", timestamp)
            print("Student registered successfully.")
        except FileNotFoundError:
            print("Students file not found.")

    def check_student_id_exists(student_id):
        try:
            with open("students.txt", "r") as file:
                for line in file:
                    existing_student_id = line.split(",")[0]
                    if str(student_id) == existing_student_id:
                        return True
            return False
        except FileNotFoundError:
            print("Students file not found.")
            return False

    def update_student_record():
        print("Update Student Record")
        student_id = validate_numeric_input("Enter Student ID to update: ")

        try:
            with open("students.txt", "r") as file:
                lines = file.readlines()

            updated = False
            with open("students.txt", "w") as file:
                for line in lines:
                    if line.startswith(student_id + ","):
                        student_name = get_valid_input("Enter Updated Student Name: ")
                        program = get_valid_input("Enter Updated Program Name: ")
                        file.write(f"{student_id},{student_name},{program}\n")
                        updated = True
                    else:
                        file.write(line)

            if updated:
                timestamp = datetime.now().strftime("%Y-%m-%d:%M:%S")
                print("student information updated on:", timestamp)
                print("Student record updated successfully.")
            else:
                print("Student ID not found.")
        except FileNotFoundError:
            print("Students file not found.")

    def manage_enrollments():
        print("Manage Enrollments")
        student_id = validate_numeric_input("Enter Student ID: ")
        module_code = get_valid_input("Enter Module Code: ")

        module_exists = False
        with open("modules.txt", "r") as module_file:
            for line in module_file:
                if line.strip() == module_code:
                    module_exists = True
                    break

        if not module_exists:
            print(f"Module code {module_code} does not exist.")
            return

        action = input("Enter Action (Enroll/Unenroll): ").strip().lower()

        try:
            if action == "enroll":
                with open("enrolments.txt", "a") as file:
                    file.write(f"{student_id},{module_code}\n")
                timestamp = datetime.now().strftime("%Y-%m-%d:%M:%S")
                print("Student enrolled in", module_code, "on:", timestamp)
                print("Student", student_id, "enrolled in module", module_code)
            elif action == "unenroll":
                found = False
                with open("enrolments.txt", "r") as file:
                    lines = file.readlines()

                with open("enrolments.txt", "w") as file:
                    for line in lines:
                        if line.strip() != f"{student_id},{module_code}":
                            file.write(line)
                        else:
                            found = True

                if found:
                    print(f"Student {student_id} unenrolled from module {module_code}.")
                else:
                    print("Enrollment record not found.")
            else:
                print("Invalid action.")
        except FileNotFoundError:
            print("Enrollments file not found.")

    def issue_transcript():
        print("Issue Transcript")
        student_id = validate_numeric_input("Enter Student ID: ")

        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        try:
            print(f"Transcript for Student ID: {student_id}")
            print("Modules and Grades:")
            with open("grades.txt", "r") as file:
                found = False
                for line in file:
                    mod_code, sid, grade = line.strip().split(",")
                    if sid == str(student_id):
                        print("Module:", mod_code, "Grade:", grade)
                        found = True
                if not found:
                    print("No grades found for this student.")
        except FileNotFoundError:
            print("Grades file not found.")

        print("Transcript generated on:", timestamp)

    def delete_student_record():
        print("Delete Student Record")
        student_id = validate_numeric_input("Enter Student ID to delete: ")

        try:
            with open("students.txt", "r") as file:
                lines = file.readlines()

            deleted = False
            with open("students.txt", "w") as file:
                for line in lines:
                    if not line.startswith(student_id + ","):
                        file.write(line)
                    else:
                        deleted = True

            if deleted:
                timestamp = datetime.now().strftime("%Y-%m-%d:%M:%S")
                print("student record deleted on :", timestamp)
                print("Student record deleted successfully.")
            else:
                print("Student ID not found.")
        except FileNotFoundError:
            print("Students file not found.")

    def view_student_information():
        print("View Student Information")
        student_id = validate_numeric_input("Enter Student ID to view: ")

        try:
            with open("students.txt", "r") as file:
                found = False
                for line in file:
                    if line.startswith(student_id + ","):
                        timestamp = datetime.now().strftime("%Y-%m-%d:%M:%S")
                        print("student info viewed on :", timestamp)
                        print("Student Details:")
                        details = line.strip().split(",")
                        print(f"ID: {details[0]}, Name: {details[1]}, Program: {details[2]}")
                        found = True
                        break

                if not found:
                    print("Student ID not found.")
        except FileNotFoundError:
            print("Students file not found.")

    while True:
        print("---------- Registrar Menu ----------")
        print("1. Register New Student")
        print("2. Update Student Record")
        print("3. Manage Enrollments")
        print("4. Issue Transcript")
        print("5. Delete Student Record")
        print("6. View Student Information")
        print("7. Exit")
        choice = input("Enter your choice: ").strip()

        if choice == "1":
            register_new_student()
        elif choice == "2":
            update_student_record()
        elif choice == "3":
            manage_enrollments()
        elif choice == "4":
            issue_transcript()
        elif choice == "5":
            delete_student_record()
        elif choice == "6":
            view_student_information()
        elif choice == "7":
            print("Exiting Registrar Menu.")
            break
        else:
            print("Invalid choice, please try again.")