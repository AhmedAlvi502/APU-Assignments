

from datetime import datetime

def lecturer_menu():
    def view_assigned_modules(lecturer_id):
        print("Viewing Assigned Modules...")
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        print(f"time-stamp: {timestamp}")
        try:
            with open("modules.txt", "r") as file:
                print("Modules assigned:")
                for line in file:
                    details = line.strip().split(",")
                    if len(details) == 4 and details[
                        3] == lecturer_id:  # Assuming lecturer_id is the 4th field in modules.txt
                        print(f"{details[0]} - {details[1]} ({details[2]} credits)")
        except FileNotFoundError:
            print("Modules file not found.")

    def view_student_list(module_code):
        print(f"Student List for Module: {module_code}")
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        print(f"time-stamp: {timestamp}")
        try:
            with open("enrolments.txt", "r") as file:
                print("Enrolled Students:")
                found = False
                for line in file:
                    line = line.strip()
                    if not line:
                        continue  # Skip empty lines
                    try:
                        student_id, mod_code = line.split(",")
                        if mod_code == module_code:
                            print(f"Student ID: {student_id}")
                            found = True
                    except ValueError:
                        print(f"Skipping invalid line: {line}")  # Optional: Debug invalid lines
                if not found:
                    print(f"No students are enrolled in module {module_code}.")
        except FileNotFoundError:
            print("Enrollments file not found.")

    def record_grades():
        print("Recording Grades...")
        module_code = input("Enter Module Code: ").strip()
        student_id = input("Enter Student ID: ").strip()
        grade = input("Enter Grade: ").strip()

        try:
            with open("grades.txt", "a") as file:
                file.write(f"{module_code},{student_id},{grade}\n")
            print("Grade recorded successfully.")
        except FileNotFoundError:
            print("Grades file not found.")

    def track_attendance():
        print("Tracking Attendance...")
        module_code = input("Enter Module Code: ").strip()
        student_id = input("Enter Student ID: ").strip()
        attendance_status = input("Enter Attendance Status (Present/Absent): ").strip()

        try:
            with open("attendance.txt", "a") as file:
                file.write(f"{module_code},{student_id},{attendance_status}\n")
            print("Attendance recorded successfully.")
        except FileNotFoundError:
            print("Attendance file not found.")

    def view_student_grades(module_code):
        print(f"Viewing Grades for Module: {module_code}")
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        print(f"time-stamp: {timestamp}")
        try:
            with open("grades.txt", "r") as file:
                print("Student Grades:")
                for line in file:
                    mod_code, student_id, grade = line.strip().split(",")
                    if mod_code == module_code:
                        print(f"Student ID: {student_id}, Grade: {grade}")
        except FileNotFoundError:
            print("Grades file not found.")

    while True:
        print("---------- Lecturer Menu ----------")
        print("1. View Assigned Modules")
        print("2. View Student List for a Module")
        print("3. Record Grades")
        print("4. Track Attendance")
        print("5. View Student Grades")
        print("6. Exit")
        choice = input("Enter your choice: ").strip()

        if choice == "1":
            lecturer_id = input("Enter your Lecturer ID: ").strip()
            view_assigned_modules(lecturer_id)
        elif choice == "2":
            module_code = input("Enter Module Code: ").strip()
            view_student_list(module_code)
        elif choice == "3":
            record_grades()
        elif choice == "4":
            track_attendance()
        elif choice == "5":
            module_code = input("Enter Module Code: ").strip()
            view_student_grades(module_code)
        elif choice == "6":
            print("Exiting Lecturer Menu.")
            break
        else:
            print("Invalid choice, please try again.")
