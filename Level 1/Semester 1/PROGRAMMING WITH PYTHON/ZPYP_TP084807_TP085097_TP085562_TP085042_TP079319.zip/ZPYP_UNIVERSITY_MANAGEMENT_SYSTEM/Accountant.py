
from datetime import datetime

def validate_numeric_input(prompt):
    """Prompt user for numeric input and validate it."""
    while True:
        value = input(prompt).strip()
        if value.isnumeric():
            return value
        print("Invalid input. Please enter a numeric value.")

def validate_date_input(prompt):
    """Prompt user for a date and validate its format (YYYY-MM-DD)."""
    while True:
        date_str = input(prompt).strip()
        try:
            datetime.strptime(date_str, "%Y-%m-%d")
            return date_str
        except ValueError:
            print("Invalid date format. Please use YYYY-MM-DD.")

def accountant_menu():
    def record_tuition_fees():
        print("Record Tuition Fees")
        student_id = input("Enter Student ID: ").strip()
        amount_paid = validate_numeric_input("Enter Amount Paid: ")
        date_of_payment = validate_date_input("Enter Date of Payment (YYYY-MM-DD): ")

        try:
            with open("fees.txt", "a") as file:
                file.write(f"{student_id},{amount_paid},{date_of_payment}\n")
            print("Tuition fee payment recorded successfully.")
        except FileNotFoundError:
            print("Fees file not found.")

    def view_outstanding_fees():
        print("View Outstanding Fees")
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        print(f"Reports generated on: {timestamp}")
        try:
            print("Outstanding Fees:")
            with open("fees.txt", "r") as file:
                for line in file:
                    details = line.strip().split(",")
                    if len(details) == 3:
                        student_id, amount_paid, date_of_payment = details
                        print(f"Student ID: {student_id}, Outstanding Fees: {amount_paid}")

        except FileNotFoundError:
            print("Fees file not found.")


    def update_payment_records():
        print("Update Payment Records")
        student_id = input("Enter Student ID: ").strip()
        new_payment = validate_numeric_input("Enter Updated Amount Paid: ")
        payment_date = validate_date_input("Enter Updated Payment Date (YYYY-MM-DD): ")

        try:
            with open("fees.txt", "r") as file:
                lines = file.readlines()

            updated = False
            with open("fees.txt", "w") as file:
                for line in lines:
                    if line.startswith(student_id + ","):
                        file.write(f"{student_id},{new_payment},{payment_date}\n")
                        updated = True
                    else:
                        file.write(line)

            if updated:
                print("Payment record updated successfully.")
            else:
                print("Student ID not found in payment records.")
        except FileNotFoundError:
            print("Fees file not found.")

    def issue_fee_receipts():
        print("Issue Fee Receipt")
        student_id = input("Enter Student ID: ").strip()

        try:
            with open("fees.txt", "r") as file:
                for line in file:
                    if line.startswith(student_id + ","):
                        details = line.strip().split(",")
                        print("Fee Receipt:")
                        print(f"Student ID: {details[0]}")
                        print(f"Amount Paid: {details[1]}")
                        print(f"Payment Date: {details[2]}")
                        return
                print("No fee record found for the given Student ID.")
        except FileNotFoundError:
            print("Fees file not found.")

    def view_financial_summary():
        print("View Financial Summary")
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        print(f"Reports generated on: {timestamp}")
        try:
            total_fees_collected = 0
            with open("fees.txt", "r") as file:
                for line in file:
                    details = line.strip().split(",")
                    if len(details) >= 2:
                        total_fees_collected += float(details[1])
            print(f"Total Fees Collected: {total_fees_collected:.2f}")
        except FileNotFoundError:
            print("Fees file not found.")
        except ValueError:
            print("Error reading fee amounts. Ensure all data is numeric.")

    while True:
        print("---------- Accountant Menu ----------")
        print("1. Record Tuition Fees")
        print("2. View Outstanding Fees")
        print("3. Update Payment Records")
        print("4. Issue Fee Receipt")
        print("5. View Financial Summary")
        print("6. Exit")
        choice = input("Enter your choice: ").strip()

        if choice == "1":
            record_tuition_fees()
        elif choice == "2":
            view_outstanding_fees()
        elif choice == "3":
            update_payment_records()
        elif choice == "4":
            issue_fee_receipts()
        elif choice == "5":
            view_financial_summary()
        elif choice == "6":
            print("Exiting Accountant Menu.")
            break
        else:
            print("Invalid choice, please try again.")
