

from datetime import datetime

def student_menu():
    def view_available_modules():
        print("Available Modules:")
        try:
            with open("modules.txt", "r") as file:
                print("Module Code - Module Name (Credits)")
                for line in file:
                    details = line.strip().split(",")
                    if len(details) >= 3:  # Ensures sufficient details are present
                        print(f"{details[0]} - {details[1]} ({details[2]} credits)")
        except FileNotFoundError:
            print("Modules file not found.")

    def enroll_in_module(student_id):
        print("Enroll in Module...")
        module_code = input("Enter Module Code: ").strip()

        try:
            with open("enrolments.txt", "a") as file:
                file.write(f"{student_id},{module_code}\n")
            timestamp = datetime.now().strftime("%Y-%m-%d:%M:%S")
            print(f"Enrolled in module {module_code} successfully on {timestamp}.")
        except FileNotFoundError:
            print("Enrollments file not found.")

    def unroll_from_module(student_id):
        print("Unroll from Module...")
        module_code = input("Enter Module Code: ").strip()

        try:
            found = False
            with open("enrolments.txt", "r") as file:
                lines = file.readlines()

            with open("enrolments.txt", "w") as file:
                for line in lines:
                    if line.strip() != f"{student_id},{module_code}":
                        file.write(line)
                    else:
                        found = True

            if found:
                timestamp = datetime.now().strftime("%Y-%m-%d:%M:%S")
                print(f"Unrolled in module {module_code} successfully on {timestamp}.")
            else:
                print(f"No enrollment found for module {module_code}.")
        except FileNotFoundError:
            print("Enrollments file not found.")

    def view_grades(student_id):
        print("Your Grades:")
        try:
            with open("grades.txt", "r") as file:
                for line in file:
                    mod_code, sid, grade = line.strip().split(",")
                    if sid == student_id:
                        print(f"Module Code: {mod_code}, Grade: {grade}")
        except FileNotFoundError:
            print("Grades file not found.")

    def access_attendance_record(student_id):
        module_code = input("Enter Module Code: ").strip()
        print(f"Attendance Records for Student ID {student_id} in Module {module_code}:")
        try:
            with open("attendance.txt", "r") as file:
                total_classes, attended_classes = 0, 0
                for line in file:
                    line = line.strip()
                    if not line:
                        continue  # Skip empty lines
                    try:
                        mod_code, sid, status = line.split(",")
                        if sid == student_id and mod_code == module_code:
                            total_classes += 1
                            if status.lower() == "present":
                                attended_classes += 1
                    except ValueError:
                        print(f"Skipping invalid line: {line}")  # Optional debug info for invalid lines

                if total_classes > 0:
                    attendance_percentage = (attended_classes / total_classes) * 100
                    print(f"Total Classes: {total_classes}")
                    print(f"Classes Attended: {attended_classes}")
                    print(f"Attendance Percentage: {attendance_percentage:.2f}%")
                else:
                    print(f"No attendance records found for Module {module_code} with your Student ID.")
        except FileNotFoundError:
            print("Attendance file not found.")

    while True:
        print("---------- Student Menu ----------")
        print("1. View Available Modules")
        print("2. Enroll in Module")
        print("3. Unroll from Module")
        print("4. View Grades")
        print("5. Access Attendance Record")
        print("6. Exit")
        choice = input("Enter your choice: ").strip()

        if choice == "1":
            view_available_modules()
        elif choice == "2":
            student_id = input("Enter your Student ID: ").strip()
            enroll_in_module(student_id)
        elif choice == "3":
            student_id = input("Enter your Student ID: ").strip()
            unroll_from_module(student_id)
        elif choice == "4":
            student_id = input("Enter your Student ID: ").strip()
            view_grades(student_id)
        elif choice == "5":
            student_id = input("Enter your Student ID: ").strip()
            access_attendance_record(student_id)
        elif choice == "6":
            print("Exiting Student Menu.")
            break
        else:
            print("Invalid choice, please try again.")